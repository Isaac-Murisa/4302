 * ASSIGNMENT DOCUMENTATION
 * 
 * 1. We have successfuly set the surface normals for the object being showed on the screen. From assignment 3, we could not place all objects
 *    in the same canvas simultaneously, therefore, we have set buttons to toggle between the shapes.
 * 2. We have successfuly set the material properties for the object being showed on the screen. 
 * 3. We have set the following buttons to turn on/off light source, each light source has a different color:
 *    "T" - pressing "T" shows the light source from the viewers camera angle. 
 *    "R" - pressing "R" shows the light source coming from the right. Pressing the button twice will switch it off.
 *    "L" - pressing "L" shows the light source coming from the left. Pressing the button twice will switch it off.
 *    Sometimes, the light source will switch off if you press the button for another light direction/source. Simply press the button again
 *    to switch it back on.
 * 4. We have developed a slider to help select the ambient light value, the default 50%.
 * 5. 
 * 6. We have set a light source whichis attached to the viewers camera. As mentioned above, it can be toggled by pressing the Key "T".
 * 7. we have set buttons and the following keys for controlling interface:
 *    "F" - Switches to flat shading of object
 *    "S" - Switcehs to smooth shading if object
 *    "T" - pressing "T" shows the light source from the viewers camera angle. 
 *    "R" - pressing "R" shows the light source coming from the right. Pressing the button twice will switch it off.
 *    "L" - pressing "L" shows the light source coming from the left. Pressing the button twice will switch it off.
 * 8. 
 * 9. Our interface consists of the light on/off toggle mentioned above, as well as WASD keys to move around the object